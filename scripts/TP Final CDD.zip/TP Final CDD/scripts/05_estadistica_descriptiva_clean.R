#Evaluacion impacto limpieza

#Las estadísticas descriptivas reportadas incluyen media, moda. mediana, desvío estándar, 
#valores mínimo y máximo, y los percentiles 25 y 75.

estadisticas(gini_interpolado)
estadisticas(pobreza_winsor)
estadisticas(ingreso_low_20_interpolado)
estadisticas(pbi_log)
estadisticas(desempleo_interpolado)
